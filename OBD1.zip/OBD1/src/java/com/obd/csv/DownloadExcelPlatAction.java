
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */




package com.obd.csv;




import com.obd.mis.ProcessRequest;
import com.obd.pojo.Camp;
import com.obd.pojo.OBDTYPE;
import com.opensymphony.xwork2.ActionSupport;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;



/**

 *

 * @author CC-E00269

 */



public class DownloadExcelPlatAction extends ActionSupport implements ServletRequestAware, SessionAware {

    ArrayList<Camp> data;
    private InputStream fileInputStream;
    private String fileName;
    private String contentDisposition;

    public String getContentDisposition() {
        return contentDisposition;
    }

    public void setContentDisposition(String contentDisposition) {
        this.contentDisposition = contentDisposition;
    }
    public InputStream getFileInputStream() {
        return fileInputStream;
    }

    public void setFileInputStream(InputStream fileInputStream) {
        this.fileInputStream = fileInputStream;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public ArrayList<Camp> getData() {
        return data;
    }

    public void setData(ArrayList<Camp> data) {
        this.data = data;
    }
    HttpServletRequest request;

    public String execute() throws Exception {
        try {
            ProcessRequest objProcessRequest = new ProcessRequest();

           ArrayList<OBDTYPE>  obj =objProcessRequest.viewplatform();
            //ArrayList<CompaginNamw> objcomps = objProcessRequest.fetechCompaginNames(usrdetails);
            HSSFWorkbook hwb=new HSSFWorkbook();
            HSSFSheet sheet =  hwb.createSheet("new sheet");

            HSSFRow cellHead = sheet.createRow(0);
            cellHead.createCell(0).setCellValue("PlatForm Details : ");
/*
   objAdminPublish.setObd(rs.getString("obd"));
               objAdminPublish.setReqType(rs.getString("rtype"));
                objAdminPublish.setTotalCalls(rs.getString("total_calls"));
                objAdminPublish.setConnected(rs.getString("connected"));
                objAdminPublish.setAvgDur(rs.getString("avg_dur"));
                objAdminPublish.setTotalCount(rs.getString("total_count"));
 */
             HSSFRow cellHead2 = sheet.createRow(1);

            sheet.addMergedRegion(CellRangeAddress.valueOf("A1:B1"));
           // cellHead2.createCell(1).setCellValue(fromDate+" - "+endDate);
            HSSFRow row = sheet.createRow(3);
            row.createCell(0).setCellValue("Type");
            row.createCell(1).setCellValue("Total Calls");
            row.createCell(2).setCellValue("Calls Connected");
            row.createCell(3).setCellValue("Duration");
            row.createCell(4).setCellValue("Total Count");


            int rowNum = 4;
            for (OBDTYPE s : obj) {
                //System.out.println("" + s.getTotalHits());
                HSSFRow dataRow = sheet.createRow(rowNum++);
                dataRow.createCell(0).setCellValue(s.getObd());
                dataRow.createCell(1).setCellValue(s.getTotalCalls());
                dataRow.createCell(2).setCellValue(s.getConnected());
                dataRow.createCell(3).setCellValue(s.getAvgDur());
                dataRow.createCell(4).setCellValue(s.getTotalCount());

            }

             setContentDisposition("attachment;filename=PlatFormDetails.xls");

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            hwb.write(baos);

            setFileInputStream(new ByteArrayInputStream(baos.toByteArray()));


            //fileName = "MyFile.xls";
           // fileInputStream = new FileInputStream(hwb.write());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }

    public void setServletRequest(HttpServletRequest hsr) {
        this.request = hsr;
    }
    Map m;

    public void setSession(Map<String, Object> map) {
        this.m = map;
    }
}
