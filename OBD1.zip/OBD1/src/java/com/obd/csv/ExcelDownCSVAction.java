/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.csv;

import com.obd.mis.ProcessRequest;
import com.obd.pojo.Camp;
import com.obd.pojo.CampCri;
import com.opensymphony.xwork2.ActionSupport;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

/**
 *
 * @author U2-E00201
 */
public class ExcelDownCSVAction extends ActionSupport implements ServletRequestAware, SessionAware {

    ArrayList<Camp> data;
    private InputStream fileInputStream;
    private String fileName;
    private String contentDisposition;

    public String getContentDisposition() {
        return contentDisposition;
    }

    public void setContentDisposition(String contentDisposition) {
        this.contentDisposition = contentDisposition;
    }
    public InputStream getFileInputStream() {
        return fileInputStream;
    }

    public void setFileInputStream(InputStream fileInputStream) {
        this.fileInputStream = fileInputStream;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public ArrayList<Camp> getData() {
        return data;
    }

    public void setData(ArrayList<Camp> data) {
        this.data = data;
    }
    HttpServletRequest request;

    public String execute() throws Exception {
        try {
             ProcessRequest objProcessRequest = new ProcessRequest();
            //FileWriter writer = new FileWriter("campdetails.csv");  String endDate = (String)request.getParameter("end");
            String fromDate =(String)request.getParameter("from");
            String end =(String)request.getParameter("end");//cli,ani,callerId
            String compparam =(String)request.getParameter("compids");
            String cli =(String)request.getParameter("cli");
            String ani =(String)request.getParameter("ani");
            String callerId =(String)request.getParameter("callerId");

              List <CampCri> obj = null;//objProcessRequest.viewCriteriaPageData(compparam,fromDate,end,ani,cli,callerId);
            //ArrayList<CompaginNamw> objcomps = objProcessRequest.fetechCompaginNames(usrdetails);
            HSSFWorkbook hwb=new HSSFWorkbook();
            HSSFSheet sheet =  hwb.createSheet("new sheet");

            HSSFRow cellHead = sheet.createRow(0);
            cellHead.createCell(0).setCellValue("Campaign Details : ");

             HSSFRow cellHead2 = sheet.createRow(1);
             //cellHead2.createCell(0).setCellValue("Date Range");

            sheet.addMergedRegion(CellRangeAddress.valueOf("A1:B1"));
           // cellHead2.createCell(1).setCellValue(fromDate+" - "+endDate);
            HSSFRow row = sheet.createRow(3);
            row.createCell(0).setCellValue("Ani");
            row.createCell(1).setCellValue("Date");
            row.createCell(2).setCellValue("Call ID");
            row.createCell(3).setCellValue("CLI");
            row.createCell(4).setCellValue("DTMF PRESSED");
            row.createCell(5).setCellValue("DURATION");

           int rowNum = 4;
            for (CampCri s : obj) {
                //System.out.println("" + s.getTotalHits());
                HSSFRow dataRow = sheet.createRow(rowNum++);
                dataRow.createCell(0).setCellValue(s.getAni());
                dataRow.createCell(1).setCellValue(s.getDate());
                dataRow.createCell(2).setCellValue(s.getCallId());
                dataRow.createCell(3).setCellValue(s.getCli());
                dataRow.createCell(4).setCellValue(s.getDtmfPressed());
                dataRow.createCell(5).setCellValue(s.getDuration());

            }

             setContentDisposition("attachment;filename=Campaign.xls");

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            hwb.write(baos);

            setFileInputStream(new ByteArrayInputStream(baos.toByteArray()));


            //fileName = "MyFile.xls";
           // fileInputStream = new FileInputStream(hwb.write());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }

    public void setServletRequest(HttpServletRequest hsr) {
        this.request = hsr;
    }
    Map m;

    public void setSession(Map<String, Object> map) {
        this.m = map;
    }
}
