/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.csv;

import com.obd.mis.ProcessRequest;
import com.obd.pojo.Camp;
import com.opensymphony.xwork2.ActionSupport;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;

/**
 *
 * @author U2-E00201
 */
public class DownloadExcel extends ActionSupport implements ServletRequestAware, SessionAware {

    ArrayList<Camp> data;
    private InputStream fileInputStream;
    private String fileName;
    private String contentDisposition;

    public String getContentDisposition() {
        return contentDisposition;
    }

    public void setContentDisposition(String contentDisposition) {
        this.contentDisposition = contentDisposition;
    }
    public InputStream getFileInputStream() {
        return fileInputStream;
    }

    public void setFileInputStream(InputStream fileInputStream) {
        this.fileInputStream = fileInputStream;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public ArrayList<Camp> getData() {
        return data;
    }

    public void setData(ArrayList<Camp> data) {
        this.data = data;
    }
    HttpServletRequest request;

    public String execute() throws Exception {
        try {
            ProcessRequest objProcessRequest = new ProcessRequest();

            /*CompanginDataIM objCompanginDataIM = new CompanginDataIM();
            ArrayList<CampaignDataID> obj = objCompanginDataIM.fetechCompaginData(compparam, usrdetails);*/


      //  int gen = Integer.parseInt(gender);

              ArrayList<Camp>   obj = objProcessRequest.viewCampData();
            //ArrayList<CompaginNamw> objcomps = objProcessRequest.fetechCompaginNames(usrdetails);
            HSSFWorkbook hwb=new HSSFWorkbook();
            HSSFSheet sheet =  hwb.createSheet("new sheet");

            HSSFRow cellHead = sheet.createRow(0);
            cellHead.createCell(0).setCellValue("Campaign Details : ");

             HSSFRow cellHead2 = sheet.createRow(1);
             //cellHead2.createCell(0).setCellValue("Date Range");

            sheet.addMergedRegion(CellRangeAddress.valueOf("A1:B1"));
           // cellHead2.createCell(1).setCellValue(fromDate+" - "+endDate);
            HSSFRow row = sheet.createRow(3);
            row.createCell(0).setCellValue("Campaign Name");
            row.createCell(1).setCellValue("interactiveFlag");
            row.createCell(2).setCellValue("cli");
            row.createCell(3).setCellValue("attemptCalls");
            row.createCell(4).setCellValue("connectedCalls");
            row.createCell(5).setCellValue("noOfConsent");
            row.createCell(6).setCellValue("status");

            int rowNum = 4;
            for (Camp s : obj) {
                //System.out.println("" + s.getTotalHits());
                HSSFRow dataRow = sheet.createRow(rowNum++);
                dataRow.createCell(0).setCellValue(s.getCampName());
                dataRow.createCell(1).setCellValue(s.getInteractiveFlag());
                dataRow.createCell(2).setCellValue(s.getCli());
                dataRow.createCell(3).setCellValue(s.getAttemptCalls());
                dataRow.createCell(4).setCellValue(s.getConnectedCalls());
                dataRow.createCell(5).setCellValue(s.getNoOfConsent());
                dataRow.createCell(6).setCellValue(s.getStatus());
            }

             setContentDisposition("attachment;filename=CampaignDetails.xls");
           
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            hwb.write(baos);

            setFileInputStream(new ByteArrayInputStream(baos.toByteArray()));


            //fileName = "MyFile.xls";
           // fileInputStream = new FileInputStream(hwb.write());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "success";
    }

    public void setServletRequest(HttpServletRequest hsr) {
        this.request = hsr;
    }
    Map m;

    public void setSession(Map<String, Object> map) {
        this.m = map;
    }
}
