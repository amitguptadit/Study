
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.action;

import com.opensymphony.xwork2.ActionSupport;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

/**

 *

 * @author CC-E00269

 */
public class SignOut extends ActionSupport implements ServletRequestAware, ServletResponseAware {

    public SignOut() {
    }

    public String execute() throws Exception {
        String strResult="fail";
        try {
             request.getSession().removeAttribute("userDetails");
        request.getSession().removeAttribute("flag");
        System.out.println("hellllllll" + request.getSession().getAttribute("userDetails"));
        request.getSession().invalidate();
        strResult="success";
        } catch (Exception e) {
            strResult="fail";
            e.printStackTrace();
        }
       
        return strResult;
    }
    HttpServletRequest request;
    HttpServletResponse response;

    public void setServletRequest(HttpServletRequest hsr) {
        this.request = hsr;
    }

    public void setServletResponse(HttpServletResponse hsr) {
        this.response = hsr;
    }
}
