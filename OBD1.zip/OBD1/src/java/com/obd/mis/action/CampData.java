
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.action;

import com.obd.mis.model.FetechData;
import com.obd.mis.modelImp.FetechImp;
import com.obd.pojo.Camp;
import com.opensymphony.xwork2.ActionSupport;
import java.util.ArrayList;

/**

 *

 * @author CC-E00269

 */
public class CampData extends ActionSupport {

    public CampData() {
    }
    ArrayList<Camp> lsAdminPublish = new ArrayList<Camp>();

    public ArrayList<Camp> getLsAdminPublish() {
        return lsAdminPublish;
    }

    public void setLsAdminPublish(ArrayList<Camp> lsAdminPublish) {
        this.lsAdminPublish = lsAdminPublish;
    }

    public String execute() throws Exception {
        String strResult = "fail";
        try {
            FetechData obj = new FetechImp();
            lsAdminPublish = obj.viewCamp();
            strResult = "success";
        } catch (Exception e) {
            strResult = "fail";
        }
        return strResult;

    }
}
