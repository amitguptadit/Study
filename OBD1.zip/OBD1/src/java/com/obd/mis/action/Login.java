
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.action;

import com.obd.mis.model.login;
import com.obd.mis.modelImp.LoginIM;

import com.opensymphony.xwork2.ActionSupport;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

/**

 *

 * @author CC-E00269

 */
public class Login extends ActionSupport implements ServletRequestAware, SessionAware, ServletResponseAware {
   
    public Login() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    private String name = "";
    private String password = "";

    public String execute() throws Exception {
        String resultString = "fail";
        try {
            login objLogin = new LoginIM();
            HashMap result = objLogin.getLogin(name, password);
            String status = (String) result.get("Status");
            if (status.equalsIgnoreCase("11")) {
                request.getSession().setAttribute("userDetails", result);
                request.getSession().setAttribute("flag", "true");
                resultString = "admin";

            } else if (status.equalsIgnoreCase("-99")) {
                addFieldError("password", "username and password mismatch");//invalid data

                resultString = "fail";
            } else if (status.equalsIgnoreCase("-13")) {
                //username mismatch
                addFieldError("password", "username and password mismatch");

                resultString = "fail";
            } else if (status.equalsIgnoreCase("-15")) {
                //pasword mismatch
                addFieldError("password", "username and password mismatch");
                resultString = "fail";
            }
        } catch (Exception e) {
            resultString = "fail";
            e.printStackTrace();
        }
        return resultString;
    }

    public void validate() {

        System.out.println(">>>>>>>>>>>>>>>>>" + getName());
        System.out.println(">>>>>>>>>>>>>>>>>" + getPassword());
        if (getName().length() == 0) {
            addFieldError("userName", "Please enter valid username");
            System.out.println(">>>>>>>> HSHSHSHSH >>>>>>>>>");
        }
        if (getPassword().length() == 0) {
            addFieldError("password", getText("Please enter valid password"));
        }
    }
    HttpServletRequest request;

    public void setServletRequest(HttpServletRequest hsr) {
        this.request = hsr;
    }
    Map m;

    public void setSession(Map map) {
        this.m = map;
    }
    HttpServletResponse response;

    public void setServletResponse(HttpServletResponse hsr) {
        this.response = hsr;
    }
}
