
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.action;

import com.obd.pojo.OBDTYPE;
import com.opensymphony.xwork2.ActionSupport;
import java.util.ArrayList;
import com.obd.mis.ProcessRequest;

/**

 *

 * @author CC-E00269

 */
public class PlatformAction extends ActionSupport {

    java.util.ArrayList<OBDTYPE> students = new ArrayList<OBDTYPE>();

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    String fromDate, endDate,type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public ArrayList<OBDTYPE> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<OBDTYPE> students) {
        this.students = students;
    }

    public PlatformAction() {
    }

    public String execute() throws Exception {
        String strResult = "fail";
        try {
            ProcessRequest objProcessRequest = new ProcessRequest();
            System.out.println(getFromDate()+"EndDate"+getEndDate()+"Type"+getType());
            students = objProcessRequest.viewplatformData(getFromDate(), getEndDate(),getType());
            strResult = "success";
        } catch (Exception e) {
            strResult = "fail";
            e.printStackTrace();
        }

        return strResult;

    }
}
