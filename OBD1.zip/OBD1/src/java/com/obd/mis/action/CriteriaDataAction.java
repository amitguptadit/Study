
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.action;

import com.obd.mis.ProcessRequest;
import com.obd.pojo.CampCri;
import com.opensymphony.xwork2.ActionSupport;   
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.displaytag.tags.TableTagParameters;
import org.displaytag.util.ParamEncoder;

/**
 *
 *
 *
 * @author CC-E00269
 *
 */
public class CriteriaDataAction extends ActionSupport implements ServletRequestAware {

    public List<CampCri> getObjCampCri() {
        return objCampCri;
    }

    public void setObjCampCri(List<CampCri> objCampCri) {
        this.objCampCri = objCampCri;
    }
    List<CampCri> objCampCri = new ArrayList<CampCri>();

    public String getAni() {
        return ani;
    }

    public void setAni(String ani) {
        this.ani = ani;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getCli() {
        return cli;
    }

    public void setCli(String cli) {
        this.cli = cli;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
    String fromDate, endDate, date, ani, cli, callerId, campid, compparam, name,avg;

    public String getAvg() {
        return avg;
    }

    public void setAvg(String avg) {
        this.avg = avg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalpage() {
        return totalpage;
    }

    public void setTotalpage(int totalpage) {
        this.totalpage = totalpage;
    }
    int totalpage;

    public String getCompparam() {
        return compparam;
    }

    public void setCompparam(String compparam) {
        this.compparam = compparam;
    }

    public String getCampid() {
        return campid;
    }

    public void setCampid(String campid) {
        this.campid = campid;
    }

    public CriteriaDataAction() {
    }

    public String execute() throws Exception {
        String strRessult="fail";
        try{
        ProcessRequest objProcessRequest = new ProcessRequest();
        String page = "1";
        System.out.println("parameter names::::" + getFromDate());
        callerId = getCallerId();
        ani = getAni();
        fromDate = getFromDate();
        compparam = getCompparam();
        cli = getCli();
        endDate = getEndDate();
        avg=getAvg();
        
        System.out.println("objCampCri" + request.getParameter((new ParamEncoder("objCampCri").encodeParameterName(TableTagParameters.PARAMETER_PAGE))));
        if (request.getParameter((new ParamEncoder("objCampCri").encodeParameterName(TableTagParameters.PARAMETER_PAGE))) != null) {
            page = request.getParameter((new ParamEncoder("objCampCri").encodeParameterName(TableTagParameters.PARAMETER_PAGE))).toString();
        }
        System.out.println(compparam + "llll" + fromDate + "ff" + endDate + "end" + page+avg);
        System.out.println(" "+compparam+"  "+fromDate+"  "+endDate+"  "+page+"  "+ani+"  "+cli+"  "+callerId);
        objCampCri = objProcessRequest.viewCriteriaData(compparam, fromDate, endDate, page, ani, cli, callerId,avg);
        totalpage =objProcessRequest.getCount(compparam,fromDate, endDate, ani, cli, callerId,avg);
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>"+totalpage);
        strRessult="success";
        }catch(Exception e){
        strRessult="fail";
        }
        return strRessult;

    }
    HttpServletRequest request;

    public void setServletRequest(HttpServletRequest hsr) {
        this.request = hsr;
    }
}
