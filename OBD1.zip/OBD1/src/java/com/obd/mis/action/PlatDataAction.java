
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.action;

import com.obd.mis.ProcessRequest;
import com.obd.pojo.OBDTYPE;
import com.opensymphony.xwork2.ActionSupport;
import java.util.ArrayList;

/**

 *

 * @author CC-E00269

 */
public class PlatDataAction extends ActionSupport {

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
    String fromDate, endDate;

    public PlatDataAction() {
    }
    java.util.ArrayList<OBDTYPE> students = new ArrayList<OBDTYPE>();

    public ArrayList<OBDTYPE> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<OBDTYPE> students) {
        this.students = students;
    }

    public String execute() throws Exception {
        String strResult = "fail";
        try {
            ProcessRequest obj = new ProcessRequest();
            String outDate = obj.getDate12(0);
            endDate = outDate.substring(0, outDate.indexOf("|"));
            fromDate = outDate.substring(outDate.indexOf("|") + 1);
            students = obj.viewplatform();
            strResult = "success";
        } catch (Exception e) {
            strResult = "fail";
        }
        return strResult;

    }
}
