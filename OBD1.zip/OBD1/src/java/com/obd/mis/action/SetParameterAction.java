
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */




package com.obd.mis.action;




import com.obd.mis.ProcessRequest;   
import com.opensymphony.xwork2.ActionSupport;



/**

 *

 * @author CC-E00269

 */



public class SetParameterAction extends ActionSupport {

String compparam,name,date,endDate,fromDate;

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getCompparam() {
        return compparam;
    }

    public void setCompparam(String compparam) {
        this.compparam = compparam;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SetParameterAction() {

    }



    public String execute() throws Exception {
        String strResult="fail";
        try{
 ProcessRequest objProcessRequest = new ProcessRequest();
        String page="1";

        if (date != null) {
            if (date.equals("0")) {
                int day = Integer.parseInt(date);
                String outDate = objProcessRequest.getDate(day);
                endDate = outDate.substring(0, outDate.indexOf("|"));
                fromDate = outDate.substring(outDate.indexOf("|") + 1);
                endDate = objProcessRequest.d_formattoMsql(endDate);
                fromDate = objProcessRequest.d_formattoMsql(fromDate);
            }
            System.out.println("endDate" + endDate + "fromdate" + fromDate);

        strResult="success";

    }}catch(Exception e){
        strResult="fail";
    e.printStackTrace();
    }
        return strResult;
    }


}