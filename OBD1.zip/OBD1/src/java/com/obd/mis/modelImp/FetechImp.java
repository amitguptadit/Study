/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.obd.mis.modelImp;

import com.obd.mis.ProcessRequest;
import com.obd.mis.model.FetechData;
import com.obd.pojo.Camp;
import java.util.ArrayList;

/**
 *
 * @author CC-E00269
 */
public class FetechImp  implements FetechData{

    public ArrayList<Camp> viewCamp() {
                ProcessRequest objProcessRequest = new ProcessRequest();
ArrayList<Camp> objCamps=objProcessRequest.viewCampData();
return objCamps;  
    }

}
