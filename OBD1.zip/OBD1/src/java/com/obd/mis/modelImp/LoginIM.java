/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis.modelImp;

import com.obd.mis.ProcessRequest;
import com.obd.mis.model.login;
import java.util.HashMap;

/**
 *
 * @author CC-E00269
 */
public class LoginIM implements login {

    public HashMap<String, String> getLogin(String email, String password) {
        ProcessRequest objProcessRequest = new ProcessRequest();     
        HashMap<String, String> result = objProcessRequest.getLoginResult(email, password);
        return result;
    }
}
