/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.obd.mis.model;

import com.obd.pojo.Camp;
import java.util.ArrayList;

/**
 *
 * @author CC-E00269
 */
public interface FetechData {
public ArrayList<Camp> viewCamp();
}
