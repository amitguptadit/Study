/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.obd.mis.model;

import java.util.HashMap;

/**
 *
 * @author CC-E00269
 */
public interface login {
HashMap <String,String> getLogin(String email,String password);
  
}
