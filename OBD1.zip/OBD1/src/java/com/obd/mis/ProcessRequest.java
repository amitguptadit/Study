/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.obd.mis;

import com.obd.pojo.Camp;
import com.obd.pojo.CampCri;
import com.obd.pojo.OBDTYPE;
import java.util.*;
import org.hibernate.*;
import java.sql.*;
import com.spice.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 *
 * @author CC-E00269
 */
public class ProcessRequest {

    public HashMap<String, String> getLoginResult(String email, String password) {


        HashMap<String, String> resultMap = new HashMap();

        Session session = null;
        Transaction txn = null;

        CallableStatement callable = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            txn = session.beginTransaction();
            callable = session.connection().prepareCall("call proc_obd_login(?,?,?,?,?)");
            callable.setString(1, email.trim());
            callable.setString(2, password.trim());
            callable.registerOutParameter(3, Types.VARCHAR);
            callable.registerOutParameter(4, Types.VARCHAR);
            callable.registerOutParameter(5, Types.VARCHAR);

            System.out.println("Callable" + callable);
            System.out.println("procedure executed" + callable.execute());
            resultMap.put("Status", callable.getString(3));
            resultMap.put("Msg", callable.getString(4));
            resultMap.put("Role", callable.getString(5));
            resultMap.put("username", email.trim());

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        return resultMap;
    }

    public ArrayList<Camp> viewCampData() {
        ArrayList<Camp> lsAdminPublish = new ArrayList<Camp>();
        Session session = null;
        Transaction txn = null;
        CallableStatement callable = null;
        ResultSet rs = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            txn = session.beginTransaction();
            System.out.println("Call procedure :::");
            callable = session.connection().prepareCall("call proc_dashboard");


            System.out.println("Call procedure :::" + callable);
            System.out.println("procedure executed" + callable.execute());
            rs = callable.getResultSet();
            while (rs.next()) {
                Camp objAdminPublish = new Camp();
                //  camp_id,camp_name,interactive_flag,cli,attempt_calls,
                //connected_calls,no_of_consent,status
                objAdminPublish.setCampID(rs.getString("camp_id"));
                objAdminPublish.setCampName(rs.getString("camp_name"));
                objAdminPublish.setInteractiveFlag("interactive_flag");
                objAdminPublish.setCli(rs.getString("cli"));
                objAdminPublish.setAttemptCalls(rs.getString("attempt_calls"));
                objAdminPublish.setConnectedCalls(rs.getString("connected_calls"));
                objAdminPublish.setNoOfConsent(rs.getString("no_of_consent"));
                objAdminPublish.setStatus(rs.getString("status"));
                lsAdminPublish.add(objAdminPublish);
            }

            //AdminPublish

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        System.out.println("data" + lsAdminPublish);
        return lsAdminPublish;
    }

    public String getDate(int diff) {
        String ret = "";
        if (diff == 1) {
            Calendar cal1 = Calendar.getInstance();
            cal1.add(Calendar.DATE, -1);

            int date1 = cal1.getTime().getDate();
            int month1 = (cal1.getTime().getMonth() + 1);
            int year1 = (cal1.getTime().getYear() + 1900);

            String today = year1 + "-" + month1 + "-" + date1;

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -diff);

            int date = cal.getTime().getDate();
            int month = (cal.getTime().getMonth() + 1);
            int year = (cal.getTime().getYear() + 1900);

            String prevDate = year + "-" + month + "-" + date;

            System.out.println("Yesterday's date = " + prevDate + "today :: " + today);

            ret = today + "|" + prevDate;
        } else {
            Calendar cal1 = Calendar.getInstance();
            cal1.add(Calendar.DATE, -0);

            int date1 = cal1.getTime().getDate();
            int month1 = (cal1.getTime().getMonth() + 1);
            int year1 = (cal1.getTime().getYear() + 1900);

            String today = year1 + "-" + month1 + "-" + date1;

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -diff);

            int date = cal.getTime().getDate();
            int month = (cal.getTime().getMonth() + 1);
            int year = (cal.getTime().getYear() + 1900);

            String prevDate = year + "-" + month + "-" + date;

            System.out.println("Yesterday's date = " + prevDate + "today :: " + today);

            ret = today + "|" + prevDate;
        }
        return ret;
    }

    public String d_formattoMsql(String d) {
        DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");
        DateFormat formatter = new SimpleDateFormat("mm/dd/yyyy");
        java.util.Date d1 = null;
        try {
            d1 = formatter1.parse(d);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        String today = formatter.format(d1);
        System.out.println("Today : " + today);
        return today;
    }

    public String d_format(String d) {
        DateFormat formatter1 = new SimpleDateFormat("mm/dd/yyyyy");
        DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
        java.util.Date d1 = null;

        try {
            d1 = formatter1.parse(d);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        String today = formatter.format(d1);
        System.out.println("Today : " + today);
        return today;
    }

    public String d_formattoMsql12(String d) {
        DateFormat formatter1 = new SimpleDateFormat("yyyy-mm-dd");
        DateFormat formatter = new SimpleDateFormat("mm/dd/yyyy");
        java.util.Date d1 = null;
        try {
            d1 = formatter1.parse(d);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        String today = formatter.format(d1);
        System.out.println("Today : " + today);
        return today;
    }

    public String d_formatmm(String d) {
        DateFormat formatter1 = new SimpleDateFormat("mm/dd/yyyyy");
        DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
        java.util.Date d1 = null;

        try {
            d1 = formatter1.parse(d);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        String today = formatter.format(d1);
        System.out.println("Today : " + today);
        return today;
    }

    public String d_formatkb12(String d) {
        DateFormat formatter1 = new SimpleDateFormat("mm/dd/yyyy");
        DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
        java.util.Date d1 = null;

        try {
            d1 = formatter1.parse(d);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        String today = formatter.format(d1);
        System.out.println("Today : " + today);
        return today;
    }

    public List<CampCri> viewCriteriaData(String campid, String startdate, String endDate, String page, String ani, String cli, String callId,String avg) {
        java.util.List<CampCri> students = new ArrayList<CampCri>();
        Session session = null;
        Transaction txn = null;
        CallableStatement callable = null;
        ResultSet rs = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();

            txn = session.beginTransaction();
            int camp = Integer.parseInt(campid);
            int mobile = -1;
            int clid = -1;
            int callid = -1;
            int avgdu=-1;
            if (ani.equals("")) {
                ani = "-1";
            } else {
                // mobile = Integer.parseInt(ani);
            }
            if (cli.equals("")) {
                clid = -1;
            } else {
                clid = Integer.parseInt(cli);
            }
            if (callId.equals("")) {
                callid = -1;
            } else {
                callid = Integer.parseInt(callId);
            }
   if(avg.equals("")){
   avgdu=-1;
   }else{
   avgdu=Integer.parseInt(avg);
   }


            int pgno = Integer.parseInt(page);
            System.out.println("Call procedure :::");
            callable = session.connection().prepareCall("call proc_campaign_details(?,?,?,?,?,?,?,?)");
            callable.setInt(1, camp);
            callable.setString(2, d_formatkb12(startdate));
            callable.setString(3, d_formatkb12(endDate));
            callable.setString(4, ani);
            callable.setInt(5, clid);
            callable.setInt(6, callid);
            callable.setInt(7, pgno);
            callable.setInt(8, avgdu);

            System.out.println("Call procedure :::" + callable);
            System.out.println("procedure executed" + callable.execute());
            rs = callable.getResultSet();
            while (rs.next()) {
                CampCri objAdminPublish = new CampCri();
                //  camp_id,camp_name,interactive_flag,cli,attempt_calls,
                //connected_calls,no_of_consent,status
                objAdminPublish.setAni(rs.getString("ani"));
                objAdminPublish.setDate(rs.getString("date"));
                objAdminPublish.setCallId(rs.getString("call_id"));
                objAdminPublish.setCli(rs.getString("cli"));
                objAdminPublish.setDtmfPressed(rs.getString("dtmf_pressed"));
                objAdminPublish.setDuration(rs.getString("duration"));
                students.add(objAdminPublish);
            }

            //AdminPublish

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        System.out.println("data" + students);
        return students;
    }

    public int getCount(String campid, String startdate, String endDate, String ani, String cli, String callId,String avg) {
        java.util.List<CampCri> students = new ArrayList<CampCri>();
        Session session = null;
        Transaction txn = null;
        int count = 0;
        CallableStatement callable = null;
        ResultSet rs = null;
        int camp = Integer.parseInt(campid);
        int mobile = -1;
        int clid = -1;
        int callid = -1;
        int avgd=-1;
        if (ani.equals("")) {
            ani = "-1";
        } else {
            // mobile = Integer.parseInt(ani);
        }
        if (cli.equals("")) {
            clid = -1;
        } else {
            clid = Integer.parseInt(cli);
        }
        if (callId.equals("")) {
            callid = -1;
        } else {
            callid = Integer.parseInt(callId);
        }
        if (avg.equals("")) {
            avgd = -1;
        } else {
            avgd = Integer.parseInt(avg);
        }
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            txn = session.beginTransaction();


            System.out.println("Call procedure :::");
            callable = session.connection().prepareCall("call pro_ret_count(?,?,?,?,?,?,?,?)");
            callable.setInt(1, camp);
            callable.setString(2, d_formatkb12(startdate));
            callable.setString(3, d_formatkb12(endDate));
            callable.setString(4, ani);
            callable.setInt(5, clid);
            callable.setInt(6, callid);
            callable.setInt(7, avgd);
            callable.registerOutParameter(8, Types.INTEGER);
            System.out.println("Call procedure :::" + callable);
            System.out.println("procedure executed" + callable.execute());
// rs = callable.getResultSet();
            count = callable.getInt(8);



            //AdminPublish

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        System.out.println("data" + students);
        return count;
    }

    public ArrayList<OBDTYPE> viewplatformData(String StartDate, String endDate,String type) {
        java.util.ArrayList<OBDTYPE> students = new ArrayList<OBDTYPE>();
        Session session = null;
        Transaction txn = null;
        CallableStatement callable = null;
        ResultSet rs = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();

            txn = session.beginTransaction();

            System.out.println("Call procedure :::");
           
            callable = session.connection().prepareCall("call  proc_criteria_platform(?,?,?)");
            callable.setString(1, d_formatkb12(StartDate));
            callable.setString(2, d_formatkb12(endDate));
            callable.setString(3, type);


            System.out.println("Call procedure :::" + callable);
            System.out.println("procedure executed" + callable.execute());
            rs = callable.getResultSet();
            while (rs.next()) {
                OBDTYPE objAdminPublish = new OBDTYPE();
                //  obd,total_calls,connected,avg_dur,total_count
                objAdminPublish.setObd(rs.getString("obd"));
                objAdminPublish.setDate(rs.getString("date"));
                objAdminPublish.setTotalCalls(rs.getString("total_calls"));
                objAdminPublish.setConnected(rs.getString("connected"));
                objAdminPublish.setAvgDur(rs.getString("avg_dur"));
                objAdminPublish.setTotalCount(rs.getString("total_count"));
                students.add(objAdminPublish);
            }

            //AdminPublish

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        System.out.println("data" + students);
        return students;
    }

    public List<CampCri> viewCriteriaPageData(String campid, String startdate, String endDate, String ani, String cli, String callId,String avg) {
        java.util.List<CampCri> students = new ArrayList<CampCri>();
        Session session = null;
        Transaction txn = null;
        CallableStatement callable = null;
        ResultSet rs = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();

            txn = session.beginTransaction();
            int camp = Integer.parseInt(campid);
            int mobile = -1;
            int clid = -1;
            int callid = -1;
            int avgd=-1;
            if (ani.equals("")) {
                ani = "-1";
            } else {
                // mobile = Integer.parseInt(ani);
            }
            if (cli.equals("")) {
                clid = -1;
            } else {
                clid = Integer.parseInt(cli);
            }
            if (callId.equals("")) {
                callid = -1;
            } else {
                callid = Integer.parseInt(callId);
            }
             if (avg.equals("")) {
                avgd = -1;
            } else {
                avgd = Integer.parseInt(avg);
            }



            //int pgno = Integer.parseInt(page);
            System.out.println("Call procedure :::");
            callable = session.connection().prepareCall("call proc_return_all_data(?,?,?,?,?,?,?)");
            callable.setInt(1, camp);
            callable.setString(2, d_formatkb12(startdate));
            callable.setString(3, d_formatkb12(endDate));
            callable.setString(4, ani);
            callable.setInt(5, clid);
            callable.setInt(6, callid);
            callable.setInt(7, avgd);
            // callable.setInt(7, pgno);

            System.out.println("Call procedure :::" + callable);
            System.out.println("procedure executed" + callable.execute());
            rs = callable.getResultSet();
            while (rs.next()) {
                CampCri objAdminPublish = new CampCri();
                //  camp_id,camp_name,interactive_flag,cli,attempt_calls,
                //connected_calls,no_of_consent,status
                objAdminPublish.setAni(rs.getString("ani"));
                objAdminPublish.setDate(rs.getString("date"));
                objAdminPublish.setCallId(rs.getString("call_id"));
                objAdminPublish.setCli(rs.getString("cli"));
                objAdminPublish.setDtmfPressed(rs.getString("dtmf_pressed"));
                objAdminPublish.setDuration(rs.getString("duration"));
                students.add(objAdminPublish);
            }

            //AdminPublish

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        System.out.println("data" + students);
        return students;
    }

    public String getDate12(int diff) {
        String ret = "";
        if (diff == 1) {
            Calendar cal1 = Calendar.getInstance();
            cal1.add(Calendar.DATE, -1);

            int date1 = cal1.getTime().getDate();
            int month1 = (cal1.getTime().getMonth() + 1);
            int year1 = (cal1.getTime().getYear() + 1900);

            String today = month1 + "/" + date1 + "-" + year1;

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -diff);

            int date = cal.getTime().getDate();
            int month = (cal.getTime().getMonth() + 1);
            int year = (cal.getTime().getYear() + 1900);

            String prevDate = month + "/" + date + "/" + year;

            System.out.println("Yesterday's date = " + prevDate + "today :: " + today);

            ret = today + "|" + prevDate;
        } else {
            Calendar cal1 = Calendar.getInstance();
            cal1.add(Calendar.DATE, -0);

            int date1 = cal1.getTime().getDate();
            int month1 = (cal1.getTime().getMonth() + 1);
            int year1 = (cal1.getTime().getYear() + 1900);

            String today = month1 + "/" + date1 + "/" + year1;

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -diff);

            int date = cal.getTime().getDate();
            int month = (cal.getTime().getMonth() + 1);
            int year = (cal.getTime().getYear() + 1900);

            String prevDate = month + "/" + date + "/" + year;

            System.out.println("Yesterday's date = " + prevDate + "today :: " + today);

            ret = today + "|" + prevDate;
        }
        return ret;
    }


     public ArrayList<OBDTYPE> viewplatform() {
        java.util.ArrayList<OBDTYPE> students = new ArrayList<OBDTYPE>();
        Session session = null;
        Transaction txn = null;
        CallableStatement callable = null;
        ResultSet rs = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();

            txn = session.beginTransaction();

            System.out.println("Call procedure :::");

            callable = session.connection().prepareCall("call  proc_obd_platform");



            System.out.println("Call procedure :::" + callable);
            System.out.println("procedure executed" + callable.execute());
            rs = callable.getResultSet();
            while (rs.next()) {
                OBDTYPE objAdminPublish = new OBDTYPE();
                //  obd,total_calls,connected,avg_dur,total_count
                objAdminPublish.setObd(rs.getString("obd"));
               objAdminPublish.setReqType(rs.getString("rtype"));
                objAdminPublish.setTotalCalls(rs.getString("total_calls"));
                objAdminPublish.setConnected(rs.getString("connected"));
                objAdminPublish.setAvgDur(rs.getString("avg_dur"));
                objAdminPublish.setTotalCount(rs.getString("total_count"));
                students.add(objAdminPublish);
            }

            //AdminPublish

        } catch (Exception e) {
            if (txn != null) {
                txn.rollback();
            }
            //log.info(e.getMessage());

            e.printStackTrace();
        } finally {
            try {
                callable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (session != null) {
                if (session.isOpen()) {
                    session.close();
                }

            }
        }
        System.out.println("data" + students);
        return students;
    }
}
