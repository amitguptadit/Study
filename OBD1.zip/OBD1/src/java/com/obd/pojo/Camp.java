/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.obd.pojo;

/**
 *
 * @author CC-E00269
 */
public class Camp {

    public String getAttemptCalls() {
        return attemptCalls;
    }

    public void setAttemptCalls(String attemptCalls) {
        this.attemptCalls = attemptCalls;
    }

    public String getCampID() {
        return campID;
    }

    public void setCampID(String campID) {
        this.campID = campID;
    }

    public String getCampName() {
        return campName;
    }

    public void setCampName(String campName) {
        this.campName = campName;
    }

    public String getCli() {
        return cli;
    }

    public void setCli(String cli) {
        this.cli = cli;
    }

    public String getConnectedCalls() {
        return connectedCalls;
    }

    public void setConnectedCalls(String connectedCalls) {
        this.connectedCalls = connectedCalls;
    }

    public String getInteractiveFlag() {
        return interactiveFlag;
    }

    public void setInteractiveFlag(String interactiveFlag) {
        this.interactiveFlag = interactiveFlag;
    }

    public String getNoOfConsent() {
        return noOfConsent;
    }

    public void setNoOfConsent(String noOfConsent) {
        this.noOfConsent = noOfConsent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
String campID,campName,interactiveFlag,cli,attemptCalls,connectedCalls,noOfConsent,status;
}
