/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.obd.pojo;

/**
 *
 * @author CC-E00269
 */
public class CampCri {

    public String getAni() {
        return ani;
    }

    public void setAni(String ani) {
        this.ani = ani;
    }

    public String getCallId() {
        return callId;
    }

    public void setCallId(String callId) {
        this.callId = callId;
    }

    public String getCli() {
        return cli;
    }

    public void setCli(String cli) {
        this.cli = cli;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDtmfPressed() {
        return dtmfPressed;
    }

    public void setDtmfPressed(String dtmfPressed) {
        this.dtmfPressed = dtmfPressed;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
String date, ani, cli ,duration,dtmfPressed ,callId;
}
