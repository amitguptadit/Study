/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.obd.pojo;

/**
 *
 * @author CC-E00269
 */
public class OBDTYPE {
String obd,totalCalls,connected,avgDur,totalCount,date,reqType;

    public String getReqType() {
        return reqType;
    }

    public void setReqType(String reqType) {
        this.reqType = reqType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAvgDur() {
        return avgDur;
    }

    public void setAvgDur(String avgDur) {
        this.avgDur = avgDur;
    }  

    public String getConnected() {
        return connected;
    }

    public void setConnected(String connected) {
        this.connected = connected;
    }

    public String getObd() {
        return obd;
    }

    public void setObd(String obd) {
        this.obd = obd;
    }

    public String getTotalCalls() {
        return totalCalls;
    }

    public void setTotalCalls(String totalCalls) {
        this.totalCalls = totalCalls;
    }

    public String getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(String totalCount) {
        this.totalCount = totalCount;
    }
}
