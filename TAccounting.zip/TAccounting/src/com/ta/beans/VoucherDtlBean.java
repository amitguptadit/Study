package com.ta.beans;

import java.util.List;

import com.ta.hibernate.EntrySet;

public class VoucherDtlBean {
String id, type,amount ,narration,date_time;
List<EntrySet> vchEntryList; 


public List<EntrySet> getVchEntryList() {
	return vchEntryList;
}

public void setVchEntryList(List<EntrySet> vchEntryList) {
	this.vchEntryList = vchEntryList;
}

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public String getAmount() {
	return amount;
}

public void setAmount(String amount) {
	this.amount = amount;
}

public String getNarration() {
	return narration;
}

public void setNarration(String narration) {
	this.narration = narration;
}

public String getDate_time() {
	return date_time;
}

public void setDate_time(String date_time) {
	this.date_time = date_time;
}



}
