package com.ta.hibernate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SalesPersonDetails {
@Id
@GeneratedValue
int id;

AccountDetails accountId;

String mobileNumber;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}

}
