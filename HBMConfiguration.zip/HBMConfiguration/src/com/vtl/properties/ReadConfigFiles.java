package com.vtl.properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.BasicConfigurator;

public class ReadConfigFiles
{
	public static String DBIP = "";
    public static String DBTYPE = "";
    public static String DBName = "";
    public static String DBUSR = "";
    public static String DBPWD = "";
    public static String DBPORT="";
    
    public static String configPath="./config/";
    //---------logger-----------
    public static Logger logger = Logger.getLogger(ReadConfigFiles.class);
    //--------------------------
    public static boolean readApplicationConfig()
    {
    	try
    	{
    		java.io.FileInputStream pin = new java.io.FileInputStream(configPath+"hibernate.properties");
            
            java.util.Properties props = new java.util.Properties();
            props.load(pin);
            DBIP = props.getProperty("DBIP");             
            DBTYPE = props.getProperty("DBTYPE");            
            DBName = props.getProperty("DBName");
            DBUSR = props.getProperty("DBUSR");
            DBPWD = props.getProperty("DBPWD");
            DBPORT=props.getProperty("DBPORT");
            logger.info("[readApplicationConfig()#DBIP is:"+DBIP+"#DBTYPE:"+DBTYPE+"#DBName:"+DBName+"#DBUSR:"+DBUSR+"#DBPWD:"+DBPWD+"#DBPORT:"+DBPORT+" ]");
            
    	}
    	catch(Exception e)
    	{
    		
    		String logstr="[ readApplicationConfig()#Exception:"+e+" ]";
			logger.error(logstr);
			e.printStackTrace();
    		return false;
    	}
    	return true;
    }
}
