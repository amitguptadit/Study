package com.vtl.hibernate.dao;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import com.vtl.properties.ReadConfigFiles;
import com.vtl.utility.HibernateUtil;

public class HBDAO
{

	/**
	 * @param args
	 */
	public static Logger logger = Logger.getLogger(HBDAO.class);
	public static void main(String[] args) 
	{
		try
		{
			PropertyConfigurator.configure(ReadConfigFiles.configPath+ "log4j.properties");
			if(ReadConfigFiles.readApplicationConfig())
			{	
				
				SessionFactory sFactory = HibernateUtil.getSessionFactory();
				Session session = sFactory.openSession();
				session.clear();
				session.beginTransaction();
				System.out.println("Hibernate session-->"+session);
				session.getTransaction().commit();
				session.flush();
				session.close();
			}
			else
			{
				System.out.println("[ Check ReadConfigFiles --> ]");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
