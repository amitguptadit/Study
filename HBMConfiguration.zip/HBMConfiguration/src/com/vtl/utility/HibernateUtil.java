package com.vtl.utility;

import java.io.File;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;


import com.vtl.properties.ReadConfigFiles;
public class HibernateUtil 
{
	
	private static final SessionFactory sessionFactory;
    static
    {
        try 
        {
        	//sessionFactory = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
        	//sessionFactory = new AnnotationConfiguration().configure(ReadConfigFiles.configPath+"hibernate.cfg.xml").buildSessionFactory();
        	//<property name="connection.url">jdbc:mysql://127.0.0.1:3306/gprs</property>
        	String DBUserName=ReadConfigFiles.DBUSR,DBPassword=ReadConfigFiles.DBPWD;
        	String DBURL="jdbc:mysql://"+ReadConfigFiles.DBIP+":"+ReadConfigFiles.DBPORT+"/"+ReadConfigFiles.DBName;
        	String DriverClass="com.mysql.jdbc.Driver";
        	Configuration cfg = new Configuration();
        	cfg.configure("hibernate.cfg.xml");        	
        	cfg.getProperties().setProperty("hibernate.connection.driver_class",DriverClass);
        	cfg.getProperties().setProperty("hibernate.connection.url",DBURL);
        	cfg.getProperties().setProperty("hibernate.connection.username",DBUserName);
        	cfg.getProperties().setProperty("hibernate.connection.password",DBPassword);
        	sessionFactory = cfg.buildSessionFactory();

        } 
        catch (Throwable ex)
        {
            // Log the exception. 
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() 
    {
        return sessionFactory;
    }

}
