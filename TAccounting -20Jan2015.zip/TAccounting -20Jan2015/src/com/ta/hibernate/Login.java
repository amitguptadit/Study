package com.ta.hibernate;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Login
{
	@Id 
	@GeneratedValue
	int id;
	private String name = "";
    private String password = "";
    @OneToOne
	@JoinColumn(name="account_id")
	AccountDetails account;
    
    
    public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public AccountDetails getAccount() {
		return account;
	}

	public void setAccount(AccountDetails account) {
		this.account = account;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
