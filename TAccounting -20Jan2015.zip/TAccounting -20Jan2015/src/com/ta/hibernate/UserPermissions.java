package com.ta.hibernate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table (name="user_permissions")
public class UserPermissions {
	@Id
	@GeneratedValue
	Integer id;
	@OneToOne( cascade = CascadeType.ALL)
	@JoinColumn(name="user_id")
	AccountDetails userId;
	Integer permKey;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public AccountDetails getUserId() {
		return userId;
	}
	public void setUserId(AccountDetails userId) {
		this.userId = userId;
	}
	public Integer getPermKey() {
		return permKey;
	}
	public void setPermKey(Integer permKey) {
		this.permKey = permKey;
	}

}
