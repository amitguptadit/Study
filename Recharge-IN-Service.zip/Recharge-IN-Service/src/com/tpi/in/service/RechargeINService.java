package com.tpi.in.service;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class RechargeINService extends HttpServlet  {

	private static final long serialVersionUID = 1L;

	private String userid = null;
	private Integer transid = 3;
	private String custmsisdn = null;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String uri=request.getRequestURI();
		
		if(uri.equals("/Recharge-IN-Service/Airtel"))
		{
			userid = request.getParameter("userid");
			if (request.getParameter("transid") != null) {
				transid = Integer.parseInt(request.getParameter("transid"));
			}
			custmsisdn = request.getParameter("custmsisdn");
	
			if (transid % 2 == 0) {
	
				response.getWriter().write("Success"); //even
			} else {
				response.getWriter().write("Fail"); //odd
			}
		}
		else if(uri.equals("/Recharge-IN-Service/Vodafone"))
		{
			userid = request.getParameter("userid");
			if (request.getParameter("transid") != null) {
				transid = Integer.parseInt(request.getParameter("transid"));
			}
			custmsisdn = request.getParameter("custmsisdn");

			if (transid % 2 == 0) {

				response.getWriter().write(" Success"); //even
			} else {
				response.getWriter().write("Fail"); //odd
			}
		}
			
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
	}

	
	
}
