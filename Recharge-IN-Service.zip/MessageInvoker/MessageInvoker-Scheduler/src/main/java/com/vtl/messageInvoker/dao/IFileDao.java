package com.vtl.messageInvoker.dao;

import java.util.List;

import com.vtl.msg.beans.Message;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.exceptions.DatabaseException;

public interface IFileDao {

	List<Message> getMessageList(String transId) throws BusinessException,
			DatabaseException;
	
	void recordInProcess(Message message, String transId)
			throws DatabaseException;

	void updateRecord(Message message, String transId)
			throws BusinessException, DatabaseException;
}
