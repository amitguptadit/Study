package com.vtl.messageInvoker.services;

import java.util.Calendar;
import java.util.List;

import com.vtl.msg.config.FileConfig;
import com.vtl.msg.exceptions.BusinessException;

/**
 * @author Anuj.Singh
 * @version 1.0
 */
public interface IFileService {

	List<String> downloadFile(FileConfig fileConfig, Calendar currCal,
			String remoteSourceFilePath, String remoteBackupFilePath,
			String localFilePath, final String fileName,
			final String fileExtension) throws BusinessException;

	List<String> downloadPaperFile(FileConfig fileConfig, Calendar currCal,
			String remoteSourceFilePath, String remoteBackupFilePath,
			String localFilePath, final String fileName,
			final String fileExtension) throws BusinessException;

	void processMessage(String transId) throws BusinessException;

	Boolean moveFiles(String remoteFilePath, String localFilePath,
			String... files);
}
