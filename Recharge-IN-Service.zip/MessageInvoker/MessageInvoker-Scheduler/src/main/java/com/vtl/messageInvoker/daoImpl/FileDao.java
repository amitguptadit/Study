package com.vtl.messageInvoker.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.vtl.messageInvoker.dao.IFileDao;
import com.vtl.msg.beans.Message;
import com.vtl.msg.exceptions.DatabaseException;
import com.vtl.msg.util.ResponseConstants;
import com.vtl.msg.util.spring.CustomBeanProvider;

public class FileDao implements IFileDao {

	private DataSource dataSource;
	private Message message;

	private final static Logger logger = Logger.getLogger(FileDao.class);

	@Override
	public List<Message> getMessageList(String transId)
			throws DatabaseException {

		Connection cnn = null;
		Statement stmt = null;
		ResultSet rs = null;
		List<Message> messageList;

		try {

			messageList = new ArrayList<Message>();
			cnn = getDataSource().getConnection();
			stmt = cnn.createStatement();
			String selectQuery = "SELECT id,msisdn,content,cli from sms_log where is_Message_Sent='0'";
			//String selectQuery = "SELECT id,msisdn,content,cli from test_sms_log where is_Message_Sent='0'";
			rs = stmt.executeQuery(selectQuery);
			logger.info("[" + transId + "] " + " Query is :" + selectQuery
					+ " and connection is :" + cnn + " and statement is : "
					+ stmt + " and resultset is :" + rs);
			
			while (rs.next()) {
								
				//logger.info("[" + transId + "] Inside the while loop...");
				//message = CustomBeanProvider.getBean("message");
				message = new Message();
				message.setId(rs.getInt("id"));
				message.setMsisdn(rs.getString("msisdn"));
				message.setContent(rs.getString("content"));
				message.setCli(rs.getString("cli"));

				messageList.add(message);
				
				//--------------------update message for In process--------------------//
				recordInProcess(message,transId);
				logger.info("[" + transId + "] message going to be in process " +messageList.size());
			}
		} catch (Exception e) {
			throw new DatabaseException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
			if (cnn != null) {
				try {
					cnn.setAutoCommit(Boolean.TRUE);
					cnn.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
		}
		return messageList;
	}
	
	@Override
	public void recordInProcess(Message message, String transId)
			throws DatabaseException {
		Connection cnn = null;
		Statement stmt = null;
		try {			
			cnn = getDataSource().getConnection();
			
			stmt = cnn.createStatement();
			String updateQuery = "update sms_log set is_Message_Sent='1',message_Sent_Date=sysdate,last_Modification_Date=sysdate where id='"+ message.getId()+ "'";
			//String updateQuery = "update test_sms_log set is_Message_Sent='1',message_Sent_Date=sysdate,last_Modification_Date=sysdate where id='"+ message.getId()+ "'";
			//logger.info("[" + transId + "] recordInProcess()#" + updateQuery);
			stmt.executeUpdate(updateQuery);
		} catch (Exception e) {
			throw new DatabaseException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
			if (cnn != null) {
				try {
					cnn.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
		}
	}

	@Override
	public void updateRecord(Message message, String transId)
			throws DatabaseException {
		Connection cnn = null;
		Statement stmt = null;
		try {

			cnn = getDataSource().getConnection();
			stmt = cnn.createStatement();
			String updateQuery = "update sms_log set is_Message_Sent='2',message_Sent_Date=sysdate,last_Modification_Date=sysdate where  id='"+ message.getId()+ "'";
			//String updateQuery = "update test_sms_log set is_Message_Sent='2',message_Sent_Date=sysdate,last_Modification_Date=sysdate where  id='"+ message.getId()+ "'";
			logger.info("[" + transId + "] " + updateQuery);
			stmt.executeUpdate(updateQuery);
		} catch (Exception e) {
			throw new DatabaseException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
			if (cnn != null) {
				try {
					cnn.close();
				} catch (SQLException e) {
					throw new DatabaseException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
			}
		}
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

}