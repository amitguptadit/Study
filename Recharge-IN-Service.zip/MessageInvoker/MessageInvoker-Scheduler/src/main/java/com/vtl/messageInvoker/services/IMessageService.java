package com.vtl.messageInvoker.services;
import com.vtl.msg.beans.Message;
public interface IMessageService {
	
	public String sendMessage(Message message,String transId);
}
