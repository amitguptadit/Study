package com.vtl.messageInvoker.schedulers;

import java.util.Calendar;

import org.apache.log4j.Logger;

import com.vtl.messageInvoker.servicesImpl.BaseUploadFacade;

/**
 * @author Anuj.Singh
 * @version 1.0
 */
public class BaseUploadScheduler {

	private final static Logger logger = Logger
			.getLogger(BaseUploadScheduler.class);

	private BaseUploadFacade baseUploadFacade;
	
	/**
	 * This method is used as a job for the base upload scheduler
	 */
	public void performTask() {
		logger.info("BaseUploadScheduler is started at "
				+ Calendar.getInstance().getTime());
		//this.startBaseUpload();
		logger.info("BaseUploadScheduler is finished at "
				+ Calendar.getInstance().getTime());
	}

	/**
	 * This method is used to perform the steps of base uploading
	 */
	/*private void startBaseUpload() {
		baseUploadFacade.startProcess();
	}*/

	public BaseUploadFacade getBaseUploadFacade() {
		return baseUploadFacade;
	}

	public void setBaseUploadFacade(BaseUploadFacade baseUploadFacade) {
		this.baseUploadFacade = baseUploadFacade;
	}	
}
