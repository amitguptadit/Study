package com.vtl.msg.util;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class HibernateUtil {

	@Autowired
	private  SessionFactory sessionFactory;


	public  SessionFactory hibernateSessionFactory;
	public SessionFactory getHibernateSessionFactory() {
		return sessionFactory;
	}

}
