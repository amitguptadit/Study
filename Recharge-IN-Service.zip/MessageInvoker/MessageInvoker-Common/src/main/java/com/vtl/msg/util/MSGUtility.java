package com.vtl.msg.util;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*;
public class MSGUtility
{

	public  static Boolean  makedir(String filepath)
	{
		Boolean dirFlag=Boolean.FALSE;
		try
		{
			File flogpath = new File(filepath+"/");
			if(!(flogpath.isDirectory()))
			{//4 if5
				flogpath.mkdirs();
			}//end if5 4
			dirFlag=Boolean.TRUE;
		}
		catch(Exception ex)
		{
			System.out.println("MSGUtility#makedir()#Exception :"+ex);
			ex.printStackTrace();
			dirFlag=Boolean.FALSE;

		}
		return dirFlag;
	}
	public  static String  date(int type)
	{//2
		  String format="yyyyMMdd";
		  if (type ==2)
			format="yyMMdd";
		  else if(type==3)
			format="yyyyMM";
		  DateFormat dateFormat = new SimpleDateFormat(format); //"yyyy/MM/dd HH:mm:ss"
		  Date date = new Date();
		  //System.out.println("[ DATE IS :"+dateFormat.format(date)+" ]");
		  return dateFormat.format(date);

	}//end date() 2
	//----------------------------[	getMonth()	]----------------------------------------------------------------
	public static String  getMonth(int type)
	{//2

			  String format="MMMyyyy";
			  if (type ==2)
			  format="MMMyyyydd";
			  else if(type==3)
			  format="MMMMyyyydd";

			  DateFormat dateFormat = new SimpleDateFormat(format); //"MMMMyyyydd/ HH:mm:ss"
			  Calendar cal= Calendar.getInstance();
			  Date date = new Date(cal.getTimeInMillis());
			  return dateFormat.format(date);

	}//getMonth
	//-------------------------[	TIME METHOD	]------------------------------------------------------------
	public static String time(int type )
	{//2
		String format="HH:mm:ss";
		if (type ==2)
		format="HHmmss";
		DateFormat dateFormat = new SimpleDateFormat(format); //"yyyy/MM/dd HH:mm:ss"
		Date date = new Date();
		//System.out.println("[ TIME IS :"+dateFormat.format(date)+" ]");
		return dateFormat.format(date);
	}//end time() 2
    //===========================================================================================================
	public static Long numberOfDays(String activationDate) {
		//SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date d1 = null;
		Date d2 = new Date();
		Long diff = null, diffDays = null;
		try {
			d1 = format.parse(activationDate);
			diff = d1.getTime() - d2.getTime();
			diffDays = diff / (24 * 60 * 60 * 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return diffDays;
	}
	public static Long diffDays(String str1,String  str2)
	{
		Long diff = null, diffDays = null;
		try {

			 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			  Date d1 = format.parse(str1);

			   Date d2 = format.parse(str2);
			   //d1 = format.parse(activationDate);
			   				diff = d2.getTime() - d1.getTime();
			   				diffDays = diff / (24 * 60 * 60 * 1000);
			  } catch (Exception e) {
			   				e.printStackTrace();
			   			}
			return diffDays;

	}
	public static Long diffDays(Date d1,Date d2)
	{

			Long diff = null, diffDays = null;
			try {
				//d1 = format.parse(activationDate);
				diff = d2.getTime() - d1.getTime();
				diffDays = diff / (24 * 60 * 60 * 1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return diffDays;
	}
}
