package com.vtl.msg.config;

public class FileConfig {

	private String remoteFileSourcePath;
	private String remoteFileBackupPath;
	private String remotePaperFileSourcePath;
	private String remotePaperFileBackupPath;
	
	private String localFilePath;
	private String backupSuccessFilePath;
	private String backupFailureFilePath;
	
	private String messageInvokerFileName;
	private String messageInvokerFileExtension;
	
	private String paperFileName;
	private String paperFileExtension;

	private String scpHost;
	private String scpUserName;
	private String scpPassword;
	private Integer scpPort;
	
	private String scpHostPaper;
	private String scpUserNamePaper;
	private String scpPasswordPaper;
	private Integer scpPortPaper;

	public String getRemoteFileSourcePath() {
		return remoteFileSourcePath;
	}

	public void setRemoteFileSourcePath(String remoteFileSourcePath) {
		this.remoteFileSourcePath = remoteFileSourcePath;
	}

	public String getRemoteFileBackupPath() {
		return remoteFileBackupPath;
	}

	public void setRemoteFileBackupPath(String remoteFileBackupPath) {
		this.remoteFileBackupPath = remoteFileBackupPath;
	}

	public String getLocalFilePath() {
		return localFilePath;
	}

	public void setLocalFilePath(String localFilePath) {
		this.localFilePath = localFilePath;
	}

	public String getBackupSuccessFilePath() {
		return backupSuccessFilePath;
	}

	public void setBackupSuccessFilePath(String backupSuccessFilePath) {
		this.backupSuccessFilePath = backupSuccessFilePath;
	}

	public String getBackupFailureFilePath() {
		return backupFailureFilePath;
	}

	public void setBackupFailureFilePath(String backupFailureFilePath) {
		this.backupFailureFilePath = backupFailureFilePath;
	}

	

	public String getScpHost() {
		return scpHost;
	}

	public void setScpHost(String scpHost) {
		this.scpHost = scpHost;
	}

	public String getScpUserName() {
		return scpUserName;
	}

	public void setScpUserName(String scpUserName) {
		this.scpUserName = scpUserName;
	}

	public String getScpPassword() {
		return scpPassword;
	}

	public void setScpPassword(String scpPassword) {
		this.scpPassword = scpPassword;
	}

	public Integer getScpPort() {
		return scpPort;
	}

	public void setScpPort(Integer scpPort) {
		this.scpPort = scpPort;
	}

	public String getMessageInvokerFileName() {
		return messageInvokerFileName;
	}

	public void setMessageInvokerFileName(String messageInvokerFileName) {
		this.messageInvokerFileName = messageInvokerFileName;
	}

	public String getMessageInvokerFileExtension() {
		return messageInvokerFileExtension;
	}

	public void setMessageInvokerFileExtension(String messageInvokerFileExtension) {
		this.messageInvokerFileExtension = messageInvokerFileExtension;
	}

	public String getRemotePaperFileSourcePath() {
		return remotePaperFileSourcePath;
	}

	public void setRemotePaperFileSourcePath(String remotePaperFileSourcePath) {
		this.remotePaperFileSourcePath = remotePaperFileSourcePath;
	}

	public String getRemotePaperFileBackupPath() {
		return remotePaperFileBackupPath;
	}

	public void setRemotePaperFileBackupPath(String remotePaperFileBackupPath) {
		this.remotePaperFileBackupPath = remotePaperFileBackupPath;
	}

	public String getPaperFileName() {
		return paperFileName;
	}

	public void setPaperFileName(String paperFileName) {
		this.paperFileName = paperFileName;
	}

	public String getPaperFileExtension() {
		return paperFileExtension;
	}

	public void setPaperFileExtension(String paperFileExtension) {
		this.paperFileExtension = paperFileExtension;
	}

	public String getScpHostPaper() {
		return scpHostPaper;
	}

	public void setScpHostPaper(String scpHostPaper) {
		this.scpHostPaper = scpHostPaper;
	}

	public String getScpUserNamePaper() {
		return scpUserNamePaper;
	}

	public void setScpUserNamePaper(String scpUserNamePaper) {
		this.scpUserNamePaper = scpUserNamePaper;
	}

	public String getScpPasswordPaper() {
		return scpPasswordPaper;
	}

	public void setScpPasswordPaper(String scpPasswordPaper) {
		this.scpPasswordPaper = scpPasswordPaper;
	}

	public Integer getScpPortPaper() {
		return scpPortPaper;
	}

	public void setScpPortPaper(Integer scpPortPaper) {
		this.scpPortPaper = scpPortPaper;
	}


}