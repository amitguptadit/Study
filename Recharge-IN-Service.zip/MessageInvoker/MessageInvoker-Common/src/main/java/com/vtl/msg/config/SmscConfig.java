package com.vtl.msg.config;

/**
 * @author Amit.gupta
 * @version 1.0
 */
public class SmscConfig {

	private String systemId;
	private String password;
	private String systemType;
	private String smscHost;
	private int smscPort;

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSystemType() {
		return systemType;
	}

	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	public String getSmscHost() {
		return smscHost;
	}

	public void setSmscHost(String smscHost) {
		this.smscHost = smscHost;
	}

	public int getSmscPort() {
		return smscPort;
	}

	public void setSmscPort(int smscPort) {
		this.smscPort = smscPort;
	}

}
