package com.vtl.msg.util;
import java.text.SimpleDateFormat;
public interface MSGConstants {
	String SEPERATOR_COMMA = ",";
	SimpleDateFormat SDF_LONG_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");

	String REPROV_DATE_FORMAT = "yyyy-MM-dd";

	Integer MSISDN_LENGTH = Integer.valueOf(12);
	Integer DATE_LENGTH = Integer.valueOf(8);

	String RECHARGEWALLET_TPI_INVALID_REQUEST_CODE = "-1";

	String RECHARGEWALLET_SERVICE_RESPONSE_CODE = "0";
	String RECHARGEWALLET_SERVICE_RESPONSE_DESCRIPTION = "Transaction Successful";

	String RECHARGEWALLET_TRANSACTION_INPROGESS_STATUS = "INPROGRESS";
	String RECHARGEWALLET_TRANSACTION_SUCCESS = "SUCCESS";

	String RECHARGEWALLET_TPI_AIRTEL_REQUEST_MODE="TCP";
	String RECHARGEWALLET_TPI_REQUEST_MODE="TCP";
	String RECHARGEWALLET_TRANSACTION_FAIL = "FAIL";
	String RECHARGEWALLET_DB_TRANSACTION_SUCCESS = "SUCCESSFULL";

	String RECHARGEWALLET_MESSAGE_SERVICE_RESPONSE_CODE = "1";
	String RECHARGEWALLET_MESSAGE_SERVICE_RESPONSE_DESCRIPTION = "Message received empty from Procedure";

	String RECHARGEWALLET_PASS_SAME_SERVICE_RESPONSE_CODE = "2";
	String RECHARGEWALLET_PASS_SAME_SERVICE_RESPONSE_DESCRIPTION = "New Pin is same as Older Pin.";

	String RECHARGEWALLET_LT_SERVICE_RESPONSE_CODE = "3";
	String RECHARGEWALLET_LT_SERVICE_RESPONSE_DESCRIPTION = "Last Transaction received empty from Procedure";

	String RECHARGEWALLET_LFT_SERVICE_RESPONSE_CODE = "4";
	String RECHARGEWALLET_LFT_SERVICE_RESPONSE_DESCRIPTION = "Last Five Transaction received empty from Procedure";

	String RECHARGEWALLET_DR_SERVICE_RESPONSE_CODE = "5";
	String RECHARGEWALLET_DR_SERVICE_RESPONSE_DESCRIPTION = "Daily Report received empty from Procedure";

	String RECHARGEWALLET_PBP_SERVICE_RESPONSE_CODE = "6";
	String RECHARGEWALLET_PBP_SERVICE_RESPONSE_DESCRIPTION = "Postpaid Payment received empty from Procedure";

	String RECHARGEWALLET_FOS_SERVICE_RESPONSE_CODE = "7";
	String RECHARGEWALLET_FOS_SERVICE_RESPONSE_DESCRIPTION = "FOS Daily Transfer Report received empty from Procedure";

	String RECHARGEWALLET_RBL_SERVICE_RESPONSE_CODE = "8";
	String RECHARGEWALLET_RBL_SERVICE_RESPONSE_DESCRIPTION = "Retailer Balance received empty from Procedure";

	String RECHARGEWALLET_TRF_SERVICE_RESPONSE_CODE = "9";
	String RECHARGEWALLET_TRF_SERVICE_RESPONSE_DESCRIPTION = "Transfer received empty from Procedure";

	String RECHARGEWALLET_WDR_SERVICE_RESPONSE_CODE = "10";
	String RECHARGEWALLET_WDR_SERVICE_RESPONSE_DESCRIPTION = "Withdrawal received empty from Procedure";

	String RECHARGEWALLET_TRI_SERVICE_RESPONSE_CODE = "11";
	String RECHARGEWALLET_TRI_SERVICE_RESPONSE_DESCRIPTION = "Transfer-IN received empty from Procedure";

	String RECHARGEWALLET_TRO_SERVICE_RESPONSE_CODE = "12";
	String RECHARGEWALLET_TRO_SERVICE_RESPONSE_DESCRIPTION = "Transfer-OUT received empty from Procedure";

	String RECHARGEWALLET_DBP_SERVICE_RESPONSE_CODE = "13";
	String RECHARGEWALLET_DBP_SERVICE_RESPONSE_DESCRIPTION = "DTH Bill Payment received empty from Procedure";

	String RECHARGEWALLET_WR_SERVICE_RESPONSE_CODE = "14";
	String RECHARGEWALLET_WR_SERVICE_RESPONSE_DESCRIPTION = "Withdrawal Report received empty from Procedure";

	String RECHARGEWALLET_QRP_SERVICE_RESPONSE_CODE = "14";
	String RECHARGEWALLET_QRP_SERVICE_RESPONSE_DESCRIPTION = "Quick Report received empty from Procedure";

	String RECHARGEWALLET_BASE_MASTER_CACHE = "RECHARGEWALLET-BASE-MASTER-CACHE";

	String PARAM_USE_CACHE_NAME = "USE_CACHE";

	String VALUE_TRUE = "true";

	String RECHARGE_TYPE_SB = "SB";
	String RECHARGE_TYPE_CVN = "CVN";
	String RECHARGE_TYPE_CVS = "CVS";
	String RECHARGE_TYPE_LT = "LT";
	String RECHARGE_TYPE_LFT = "LFT";
	String RECHARGE_TYPE_DR = "DR";
	String RECHARGE_TYPE_PBP = "PBP";
	String RECHARGE_TYPE_FR = "FR";
	String RECHARGE_TYPE_RBL = "RBL";
	String RECHARGE_TYPE_TRF = "TRF";
	String RECHARGE_TYPE_WDR = "WDR";
	String RECHARGE_TYPE_WR = "WR";
	String RECHARGE_TYPE_QRP = "QRP";
	String RECHARGE_TYPE_TRI = "TRI";
	String RECHARGE_TYPE_TRO = "TRO";
	String RECHARGE_TYPE_PINCHANGE = "PASS";

	String IN_USERNAME = "CRM";
	String IN_PWD = "cGFzc3dvcmQx";

	String SEPERATOR_MSG = "|";
	String SEPERATOR_X = "x";

	String YES = "Y";
	String NO = "N";
	String NA = "NA";

	String PRODUCT_TYPE_TFLEXI = "1"; // CVN
	String PRODUCT_TYPE_STV = "2"; // CVS
	String PRODUCT_TYPE_FRC = "3"; // CVS
	String PRODUCT_TYPE_SRCRECH = "4"; // CVS
	String PRODUCT_TYPE_SRCTOP = "5"; // CVN

	String PROC_PROCESS_STK_REQUEST = "SPARK.PKG_STK.PROCESS_STK_REQUEST";
	String PROC_PROCESS_WEB_REQUEST = "SPARK.PKG_WEB.PROCESS_WEB_REQUEST";
	String PROC_TRANSACTION_UPDATE = "SPARK.PKG_STK.TRANSACTION_UPDATE";
	String CUSTOMER_MESSAGE = "Your account has been Recharge Successfully with Rs.";

	String POSTPAID_VALIDATION_MESSAGE = "Your Agent Pin is Invalid";

	Integer NO_OF_PIPES = 1;

	String POSTPAID_PAYMENT_TYPE = "BP";
	String POSTPAID_PAYMENT_REQUEST = "POSTPAID_PAYMENT_REQUEST";
	String POSTPAId_TECH_FAILURE = "Technical Failure";

	String CLIENT_TYPE_SMSC = "STK";
	String CLIENT_TYPE_TPI = "PC";

	String VENDOR_CODE_SMSC = "STKQTL";
	String VENDOR_CODE_TPI = "QTL";

	String USER_ID_SMSC = "SMSC";
	String USER_ID_TPI = "TPI";

	String COMPANY_CODE_VIDEOCON = "VTL";
	//for testing need to be configured String COMPANY_CODE_AIRTEL = "AIRTEL";
	String COMPANY_CODE_AIRTEL = "VTL";
	String COMPANY_CODE_VODAFONE = "VODAFONE";
	String COMPANY_CODE_QUADRANT = "QUADRANT";

	//String OPERATOR_CODE_VIDEOCON = "QTL";
	String OPERATOR_CODE_VIDEOCON = "VTL";
	String OPERATOR_CODE_AIRTEL = "ARTL";
	String OPERATOR_CODE_VODAFONE = "VODA";
	String OPERATOR_CODE_QUADRANT = "QTL";
	String OPERATOR_CODE_TATA = "TATA";

	String TPI_RECHARGE_XML = "<vtl><header><responsetype>RESPONSE_TYPE</responsetype></header><response><agentcode>AGENT_CODE</agentcode><source>SOURCE</source><agenttransid>AGENT_TRANSID</agenttransid><vendorcode>VENDOR_CODE</vendorcode><productcode>PRODUCT_CODE</productcode><amount>RECHARGE_AMOUNT</amount><sourcebankcode>SRC_BANKCODE</sourcebankcode><destination>DESTINATION</destination><type>RECHARGE_TYPE</type><inval>INVAL</inval><range>RANGE</range><poamt>POAMT</poamt><pramt>PRAMT</pramt><destinationbankcode>DEST_BANKCODE</destinationbankcode><transid>TRANS_ID</transid><resultcode>RESULT_CODE</resultcode><resultdescription>RESULT_DESC</resultdescription><vendortransid>VENDOR_TRANSID</vendortransid><requestcts>REQUEST_CTS</requestcts><responsects>RESPONSE_CTS</responsects><clienttype>CLIENT_TYPE</clienttype><responsevalue>RESPONSE_VALUE</responsevalue><udv1>UDV1</udv1><walletbalance>WALLET_BALANCE</walletbalance><fee>FEE</fee><alert>ALERT</alert><state>STATE</state><tax>TAX</tax><prewalletbalance>PRE_WALLET_BAL</prewalletbalance><processingfee>PRF</processingfee></response></vtl>";
	String TPI_BALANCE_XML = "<vtl><header><responsetype>RESPONSE_TYPE</responsetype> </header><response><agentcode>AGENT_CODE</agentcode><agentname>AGENT_NAME</agentname><source>SOURCE</source><destination>DESTINATION</destination><agenttransid>AGENT_TRANSID</agenttransid><vendorcode>VENDOR_CODE</vendorcode><amount>AMOUNT</amount><transid>TRANS_ID</transid><resultcode>RESULT_CODE</resultcode><resultdescription>RESULT_DESC</resultdescription><requestcts>REQUEST_CTS</requestcts><responsects>RESPONSE_CTS</responsects><clienttype>CLIENT_TYPE</clienttype><responsevalue>RESPONSE_VALUE</responsevalue><comments>COMMENTS</comments></response></vtl>";
	String TPI_PBP_XML = "<vtl><header><responsetype>RESPONSE_TYPE</responsetype> </header><response><agentcode>AGENT_CODE</agentcode><agentname>AGENT_NAME</agentname><source>SOURCE</source><destination>DESTINATION</destination><agenttransid>AGENT_TRANSID</agenttransid><vendorcode>VENDOR_CODE</vendorcode><amount>AMOUNT</amount><transid>TRANS_ID</transid><resultcode>RESULT_CODE</resultcode><resultdescription>RESULT_DESC</resultdescription><requestcts>REQUEST_CTS</requestcts><responsects>RESPONSE_CTS</responsects><clienttype>CLIENT_TYPE</clienttype><responsevalue>RESPONSE_VALUE</responsevalue><comments>COMMENTS</comments></response></vtl>";
	String TPI_SOCKET_RESPONSE="<?xml version="+"\""+1+"."+0+"\""+" encoding=\"UTF"+"-"+8+"\"?><ServiceResponse><responseCode>RESCODE</responseCode><responseMsg>MESSAGE</responseMsg></ServiceResponse>";
}
