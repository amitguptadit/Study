package com.vtl.msg.servicesImpl;

//import org.apache.log4j.Logger;

import com.vtl.msg.cache.MSGCacheManager;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.exceptions.DatabaseException;
import com.vtl.msg.services.ICacheService;

public class CacheService implements ICacheService {
	private MSGCacheManager ppsCacheManager;
	private Integer ppsCacheSize;

	//private final static Logger logger = Logger.getLogger(CacheService.class);


	@Override
	public Boolean cachePPSServicePlanConfiguration() throws BusinessException,
			DatabaseException {
		Boolean flag = Boolean.FALSE;

		return flag;
	}

	public MSGCacheManager getPpsCacheManager() {
		return ppsCacheManager;
	}

	public void setPpsCacheManager(MSGCacheManager ppsCacheManager) {
		this.ppsCacheManager = ppsCacheManager;
	}

	public Integer getPpsCacheSize() {
		return ppsCacheSize;
	}

	public void setPpsCacheSize(Integer ppsCacheSize) {
		this.ppsCacheSize = ppsCacheSize;
	}

}