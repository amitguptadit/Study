package com.vtl.msg.config;


public class UmfConfig {

	private String umfInterface;
	private String umfUserName;
	private String umfPassword;

	private String smsText;
	private String senderName;
	private String errorText;

	public String getUmfInterface() {
		return umfInterface;
	}

	public void setUmfInterface(String umfInterface) {
		this.umfInterface = umfInterface;
	}

	public String getUmfUserName() {
		return umfUserName;
	}

	public void setUmfUserName(String umfUserName) {
		this.umfUserName = umfUserName;
	}

	public String getUmfPassword() {
		return umfPassword;
	}

	public void setUmfPassword(String umfPassword) {
		this.umfPassword = umfPassword;
	}

	public String getSmsText() {
		return smsText;
	}

	public void setSmsText(String smsText) {
		this.smsText = smsText;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}


	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

}
