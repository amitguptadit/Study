package com.vtl.msg.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;

import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.util.MSGConstants;
import com.vtl.msg.util.ResponseConstants;

public class MSGInterfaceService {
	private static final Logger logger = Logger
			.getLogger(MSGInterfaceService.class);
	private String rechargeWalletServiceInterface;
	private String rechargeWalletAirtelServiceInterface;
	private String rechargeWalletVodafoneServiceInterface;
	private String rechargeWalletQuadrantServiceInterface;

	public void callRechargeWalletService()
			throws BusinessException {
		BufferedReader br = null;
		InputStreamReader isr = null;
		URL destUrl = null;
		HttpURLConnection urlConn = null;
		try {

		} catch (Exception e) {
			if (!(e instanceof BusinessException)) {
				throw new BusinessException(
						ResponseConstants.ERR_SYSTEM_EXCEPTION
								.getResponseCode(),
						ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(),
						e);
			}
		} finally {
			if (isr != null) {
				try {
					isr.close();
				} catch (Exception e) {
					throw new BusinessException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
				isr = null;
			}
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {
					throw new BusinessException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
				br = null;
			}
			if (urlConn != null) {
				urlConn.disconnect();
				urlConn = null;
			}
		}
	}

	public String callThrdPartyServiceInterface(
			) throws BusinessException {

		BufferedReader br = null;
		InputStreamReader isr = null;
		URL destUrl = null;
		HttpURLConnection urlConn = null;
		StringBuffer response = new StringBuffer("");
		try {

					} catch (Exception e) {
			if (!(e instanceof BusinessException)) {
				throw new BusinessException(
						ResponseConstants.ERR_SYSTEM_EXCEPTION
								.getResponseCode(),
						ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(),
						e);
			}
		} finally {
			if (isr != null) {
				try {
					isr.close();
				} catch (Exception e) {
					throw new BusinessException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
				isr = null;
			}
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {
					throw new BusinessException(
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseCode(),
							ResponseConstants.ERR_SYSTEM_EXCEPTION
									.getResponseMsg(), e);
				}
				br = null;
			}
			if (urlConn != null) {
				urlConn.disconnect();
				urlConn = null;
			}
		}
		return response.toString();
	}

	public String getRechargeWalletServiceInterface() {
		return rechargeWalletServiceInterface;
	}

	public void setRechargeWalletServiceInterface(
			String rechargeWalletServiceInterface) {
		this.rechargeWalletServiceInterface = rechargeWalletServiceInterface;
	}

	public String getRechargeWalletAirtelServiceInterface() {
		return rechargeWalletAirtelServiceInterface;
	}

	public void setRechargeWalletAirtelServiceInterface(
			String rechargeWalletAirtelServiceInterface) {
		this.rechargeWalletAirtelServiceInterface = rechargeWalletAirtelServiceInterface;
	}

	public String getRechargeWalletVodafoneServiceInterface() {
		return rechargeWalletVodafoneServiceInterface;
	}

	public void setRechargeWalletVodafoneServiceInterface(
			String rechargeWalletVodafoneServiceInterface) {
		this.rechargeWalletVodafoneServiceInterface = rechargeWalletVodafoneServiceInterface;
	}

	public String getRechargeWalletQuadrantServiceInterface() {
		return rechargeWalletQuadrantServiceInterface;
	}

	public void setRechargeWalletQuadrantServiceInterface(
			String rechargeWalletQuadrantServiceInterface) {
		this.rechargeWalletQuadrantServiceInterface = rechargeWalletQuadrantServiceInterface;
	}
}
