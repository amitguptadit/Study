package com.vtl.msg.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ServiceResponse")
public class ServiceResponse
{

    private String responseCode;
    private String responseMsg;

    private String transId;
    public ServiceResponse()
    {
    }

    public String getResponseCode()
    {
        return responseCode;
    }

    public void setResponseCode(String responseCode)
    {
        this.responseCode = responseCode;
    }

    public String getResponseMsg()
    {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg)
    {
        this.responseMsg = responseMsg;
    }

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}
    
}
