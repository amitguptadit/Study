package com.vtl.msg.util;

/**
 * @author Amit gupta
 * @version 1.0
 */
public enum ResponseConstants {
	/*SUCCESS_MESSAGE("SVC000", "SUCCESSFULL"),*/
	SUCCESS_MESSAGE("SVC00", "SUCCESSFULL"),
	ERR_SYSTEM_EXCEPTION("SVC001","Exception while process request, Kindly contact administrator"),
	ERR_DIRECTORY_NOT_EXIST("SVC002","The following directory does not exist : "),
	ERR_INVALID_PACKET("SVC003","The packet received on socket from IN is invalid"),
	ERR_INVALID_IMSI("SVC004","The value of the IMEI is invalid"),
	ERR_INVALID_MSISDN("SVC005","The value of the MSISDN is invalid"),
	ERR_INVALID_FACEVALUE("SVC006","The value of the FaceValue is invalid"),
	ERR_INVALID_EVENTTYPE("SVC007","The value of the EventType is invalid"),
	ERR_INVALID_USERTYPE("SVC008","The value of the UserType is invalid"),
	ERR_INVALID_CIRCLEID("SVC009","The value of the CircleId is invalid"),
	ERR_INVALID_SERVICENAME("SVC010","ServiceName is invalid"),
	ERR_INVALID_FROMPLAN("SVC011","FROM Plan is invalid"),
	ERR_INVALID_TOPLAN("SVC012","To Plan is invalid"),
	ERR_INVALID_PLANDATE("SVC013","Plan Date is invalid"),
	ERR_MISSING_PARAMETER("SVC014","Parameters are missing"),
	ERR_INVALID_UNSUBDATE("SVC015","Date format should be ddmmyyyy and numeric and date can not be yesterday date."),
	NOT_VALID_VIDEOCON_SUBSCRIBER("SVC016","Not a valid Videocon subscriber"),
	NOT_VALID_REQUEST("SVC016","Request Rejected due to invalid time interval"),
	ERR_INVALID_AMOUNT("SVC017","Recharge Amount in not Valid"),
	TRANS_SUCCESS_STATUS("SVC018","S"),
	TRANS_FAIL_STATUS("SVC019","F"),
	FAIL_ACCUMULATOR_ID("SVC020","Fail Accumulator Id.Recharge Not Allowed."),
	NOT_VALID_USER_ID("SVC021","Request Rejected due to invalid USER_ID or Client Type or IP Address"),
	NOT_VALID_MSISDN("SVC022","Request Rejected due to invalid msisdn"),
	NOT_VALID_UMF_USERNAME("SVC023","Request Rejected due to invalid username"),
	NOT_VALID_UMF_PASSWORD("SVC024","Request Rejected due to invalid password"),

	CASE1("FRC001","Not Go for FRC because AllowMultiple : N and IN Offer Id is match and IN Date is NULL  but procFRCActDateFlag is N "),
	CASE2("FRC002","Not Go for FRC because AllowMultiple : N  and IN Offer Id is match and IN Date is NOT NULL  but days difference  is  Negative (it Should be Positive) "),
	CASE3("FRC003","Not Go for FRC because AllowMultiple : N  and IN Offer Id is not match  "),
	/*CASE1("FRC001","Not Go for FRC because AllowMultiple : Y and IN Date is NULL but procFRCActDateFlag is N"),
	CASE2("FRC002","Not Go for FRC because AllowMultiple :Y and IN Date is NOT NULL but days difference  is  Negative (it Should be Positive)"),
	CASE3("FRC003","Not Go for FRC because AllowMultiple :N  and IN Date is NULL"),
	CASE4("FRC004","Not Go for FRC because AllowMultiple :N  and IN Date is NOT NULL but days difference  is  Negative (it Should be Positive)  "),
	*/
	FAIL_MESSAGE("FRC005","FAIL"),
	FAIL_IN_TRANSACTION("IN001","IN TRANSACTION FAILED"),

	SERVICE_RESPONSE_MSG1("RES001","FRC ,AllowMultiple is Y"),
	SERVICE_RESPONSE_MSG2("RES002","FRC ,AllowMultiple is N , IN OfferId is contain  in procOfferId ,IN Date is   NULL  but procFRCActDateFlag  is  Y"),
	SERVICE_RESPONSE_MSG3("RES003","FRC ,AllowMultiple is N , IN OfferId is contain  in procOfferId ,IN Date is   NULL  but procFRCActDateFlag  is  N"),
	SERVICE_RESPONSE_MSG4("RES004","FRC ,AllowMultiple is N , IN OfferId is contain  in procOfferId ,IN Date is  NOT  NULL   and days difference (procNoOfDays - apiActivationDays) is Positive"),
	SERVICE_RESPONSE_MSG5("RES005","FRC ,AllowMultiple is N , IN OfferId is contain  in procOfferId ,IN Date is  NOT  NULL  but days difference (It  should be Positive) is Negative"),
	SERVICE_RESPONSE_MSG6("RES006","FRC ,AllowMultiple is N but procOfferId  does not contain IN PrimaryOfferID ( IN OfferId should be present is in procOfferId)"),

	SERVICE_RESPONSE_MSG7("RES007","SRCRecharge ,IN Date is NOT NULL  but days difference of procNoOfDays and IN daysDeffrence is positive ."),
	SERVICE_RESPONSE_MSG8("RES008","SRCRecharge ,IN Date is NOT NULL  but days difference of procNoOfDays and IN daysDeffrence is Negative (It should be positive)."),

	SERVICE_RESPONSE_MSG9("RES009","CVN TFLEXI , Successfull from IN  API's ."),
	SERVICE_RESPONSE_MSG10("RES010","CVN TFLEXI , Failure from IN  API's ."),

	SERVICE_RESPONSE_MSG11("RES011","CVN SRCTOP , Days Difference from FRC is positive."),
	SERVICE_RESPONSE_MSG12("RES012","CVN SRCTOP , Days Difference from FRC is negative."),


	SERVICE_RESPONSE_MSG13("RES013","CVS STV , Successfull from IN  API's ."),
	SERVICE_RESPONSE_MSG14("RES014","CVS STV , Failure from IN  API's ."),
	SERVICE_RESPONSE_MSG15("RES015","CVN SRCTOP , Successfull from IN  API's ."),
	;

	private final String responseCode;
	private final String responseMsg;

	private ResponseConstants(String responseCode, String responseMsg) {
		this.responseCode = responseCode;
		this.responseMsg = responseMsg;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

}
