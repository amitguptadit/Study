package com.vtl.msg.services;


public interface IMSG
{
	public Integer gettingTansLowId();
	public Integer gettingTransHighId();
	public String sendMessage(String transId,String msisdn ,String msgContent,String cli);
	public Boolean checkUmfUserName(int transId,String umf_UserName);
	public Boolean checkUmfPassword(int transId,String umf_Password);
}
