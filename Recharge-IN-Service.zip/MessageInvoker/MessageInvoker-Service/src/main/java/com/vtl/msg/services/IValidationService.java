package com.vtl.msg.services;

import com.vtl.msg.beans.ServiceResponse;
import com.vtl.msg.beans.ValidationResponse;
import com.vtl.msg.exceptions.BusinessException;


public interface IValidationService {
//logger.info("msisdn : " + msisdn + " # cli : " + cli + " # content : "+ content);
	
	public ValidationResponse validateParam(int transId,String msisdn,String cli,String content,String username,String password)throws BusinessException;
	public ValidationResponse validateMsisdn(int transId,String msisdn)throws BusinessException;
	public ValidationResponse validateUserPassword(int transId,Boolean isValidUSER,Boolean isValidPASSWORD)throws BusinessException;

}
