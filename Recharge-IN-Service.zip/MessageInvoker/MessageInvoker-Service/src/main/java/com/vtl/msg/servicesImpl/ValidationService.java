package com.vtl.msg.servicesImpl;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.vtl.msg.beans.ValidationResponse;
import com.vtl.msg.exceptions.BusinessException;
import com.vtl.msg.services.IMSG;
import com.vtl.msg.services.IValidationService;
import com.vtl.msg.util.ResponseConstants;
import com.vtl.msg.util.spring.CustomBeanProvider;

public class ValidationService implements IValidationService {

	private static final Logger logger = Logger
			.getLogger(ValidationService.class);

	@Autowired
	private ValidationResponse validationResponse;

	@Override
	public ValidationResponse validateParam(int transId, String msisdn,
			String cli, String content, String username, String password)
			throws BusinessException {

		Boolean isValid = Boolean.FALSE;
		try {

			if (msisdn.equalsIgnoreCase("") || msisdn.equals("")
					|| cli.equalsIgnoreCase("") || cli.equals("")
					|| content.equalsIgnoreCase("") || content.equals("")
					|| username.equalsIgnoreCase("") || username.equals("")
					|| password.equalsIgnoreCase("") || password.equals("")) {

				logger.info("[" + transId + "] "
						+ " Missing Perameter value MSISDN : " + msisdn
						+ " # CLI : " + cli + " # Content : " + content);

				validationResponse
						.setValidateRespCode(ResponseConstants.ERR_MISSING_PARAMETER
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.ERR_MISSING_PARAMETER
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);
			} else if (!msisdn.equals("NA") && !(cli.equals("NA"))
					&& !(content.equals("NA")) && !username.equals("NA")
					&& !password.equals("NA")) {

				validationResponse = validateMsisdn(transId, msisdn);

				if (validationResponse.getValidateRespFlag()) {
					IMSG imsg = CustomBeanProvider.getBean("imsg");
					logger.info("[" + transId
							+ "] Validating UMF User Name and Password.");
					Boolean isValidUSER = imsg.checkUmfUserName(transId,
							username);
					Boolean isValidPASSWORD = imsg.checkUmfPassword(transId,
							password);

					validationResponse = validateUserPassword(transId,
							isValidUSER, isValidPASSWORD);

				}

			} else {
				logger.info("[" + transId + "] "
						+ "Missing Perameter value, MSISDN : " + msisdn
						+ " # CLI : " + cli + " # Content : " + content
						+ " # UserName :" + username + " # Password :"
						+ password);
				validationResponse
						.setValidateRespCode(ResponseConstants.ERR_MISSING_PARAMETER
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.ERR_MISSING_PARAMETER
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);
			}
		} catch (Exception ex) {
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			ex.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
					.getResponseCode()
					+ ":"
					+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":" + stack.toString());

			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), ex);

		}

		return validationResponse;
	}

	@Override
	public ValidationResponse validateMsisdn(int transId, String msisdn)
			throws BusinessException {
		Boolean isValid = Boolean.FALSE;
		try {
			int msisdn_len = msisdn.length();
			if (msisdn_len == 12 && msisdn.startsWith("91")) {
				msisdn = msisdn.substring(2, msisdn.length());
			}
			if ((msisdn.length() == 12 && !msisdn.startsWith("91"))
					|| (msisdn.length() > 10) || (msisdn.length() < 10)) {
				logger.info("[" + transId + "] " + " Invalid MSISDN : "
						+ msisdn);

				validationResponse
						.setValidateRespCode(ResponseConstants.NOT_VALID_MSISDN
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.NOT_VALID_MSISDN
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);

			} else {

				isValid = Boolean.TRUE;
				validationResponse
						.setValidateRespCode(ResponseConstants.SUCCESS_MESSAGE
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.SUCCESS_MESSAGE
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);
			}
		} catch (Exception ex) {
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			ex.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
					.getResponseCode()
					+ ":"
					+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":" + stack.toString());

			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), ex);

		}

		return validationResponse;
	}

	@Override
	public ValidationResponse validateUserPassword(int transId,
			Boolean isValidUSER, Boolean isValidPASSWORD)
			throws BusinessException {
		try {
			Boolean isValid = Boolean.FALSE;
			if (!isValidUSER) {
				validationResponse
						.setValidateRespCode(ResponseConstants.NOT_VALID_UMF_USERNAME
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.NOT_VALID_UMF_USERNAME
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);

			} else if (!isValidPASSWORD) {
				validationResponse
						.setValidateRespCode(ResponseConstants.NOT_VALID_UMF_PASSWORD
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.NOT_VALID_UMF_PASSWORD
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);

			}
			if (isValidUSER && isValidPASSWORD) {
				isValid = Boolean.TRUE;
				validationResponse
						.setValidateRespCode(ResponseConstants.SUCCESS_MESSAGE
								.getResponseCode());
				validationResponse
						.setServiceResponseMsg(ResponseConstants.SUCCESS_MESSAGE
								.getResponseMsg());
				validationResponse.setValidateRespFlag(isValid);
			}

		} catch (Exception ex) {
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			ex.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION
					.getResponseCode()
					+ ":"
					+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":" + stack.toString());

			throw new BusinessException(
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),
					ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), ex);

		}
		return validationResponse;
	}

}
