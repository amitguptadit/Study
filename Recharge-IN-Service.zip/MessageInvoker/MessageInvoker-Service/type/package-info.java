@javax.xml.bind.annotation.XmlSchema(namespace = "rm:type")
package rm.type;
